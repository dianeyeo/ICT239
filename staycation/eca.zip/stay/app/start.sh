pip install -r requirements.txt
export PYTHONPATH=.;
export FLASK_ENV=development;
export FLASK_APP=app.py;
flask run